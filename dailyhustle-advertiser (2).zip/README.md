DailyHustle Starter
===================

Two React starter projects: admin and advertiser.

How to run:
1. cd into the project folder (dailyhustle-admin or dailyhustle-advertiser)
2. npm install
3. npm run dev

This is a lightweight, well-commented starting point. Customize components, styles, and logic as needed.
